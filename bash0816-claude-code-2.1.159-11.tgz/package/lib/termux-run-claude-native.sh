#!/usr/bin/env sh
set -eu

SOURCE_BIN="${SOURCE_BIN:?SOURCE_BIN is required}"
WORKDIR="${WORKDIR:-${HOME}/.claude-termux-native-package/launcher-workdir}"
ENTRY_JS_OFFSET="${ENTRY_JS_OFFSET:?ENTRY_JS_OFFSET is required}"
ENTRY_END_OFFSET="${ENTRY_END_OFFSET:?ENTRY_END_OFFSET is required}"
CURRENT_CLAUDE_VERSION="${CURRENT_CLAUDE_VERSION:?CURRENT_CLAUDE_VERSION is required}"
CLAUDE_TERMUX_PACKAGE_DIR="${CLAUDE_TERMUX_PACKAGE_DIR:?CLAUDE_TERMUX_PACKAGE_DIR is required}"
TERMUX_TMPDIR="${TMPDIR:-/data/data/com.termux/files/usr/tmp}"
SSL_CERT_DIR="${SSL_CERT_DIR:-/data/data/com.termux/files/usr/etc/tls}"
SSL_CERT_FILE="${SSL_CERT_FILE:-/data/data/com.termux/files/usr/etc/tls/cert.pem}"
DISABLE_AUTOUPDATER="${DISABLE_AUTOUPDATER:-1}"

need_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "Missing required command: $1" >&2
    exit 1
  fi
}

need_cmd node
need_cmd termux-open-url

if [ ! -f "${SOURCE_BIN}" ]; then
  echo "Missing source binary: ${SOURCE_BIN}" >&2
  exit 1
fi

mkdir -p "${WORKDIR}"
mkdir -p "${TERMUX_TMPDIR}"

export TMPDIR="${TERMUX_TMPDIR}"
export SSL_CERT_DIR
export SSL_CERT_FILE
export DISABLE_AUTOUPDATER
export SOURCE_BIN
export WORKDIR
export ENTRY_JS_OFFSET
export ENTRY_END_OFFSET
export CURRENT_CLAUDE_VERSION

_pf=0
for _a in "$@"; do
  case "$_a" in
    -p|--print) _pf=1; break ;;
    --) break ;;
  esac
done

if [ "$_pf" = "1" ] && [ "${CLAUDE_TERMUX_STDIN:-}" != "inherit" ]; then
  _helper=$(mktemp "${TMPDIR:-/tmp}/claude-helper.XXXXXX.js")
  trap 'rm -f "$_helper"' EXIT HUP INT TERM
  cat <<'NODE' > "$_helper"
const fs = require('fs');
const path = require('path');
const {
  BLOCK_MESSAGE,
  createGuardedChildProcess,
} = require(path.join(process.env.CLAUDE_TERMUX_PACKAGE_DIR, 'lib', 'native-update-guard.js'));

const sourceBin = process.env.SOURCE_BIN;
const workdir = process.env.WORKDIR;
const entryJsOffset = Number(process.env.ENTRY_JS_OFFSET);
const entryEndOffset = Number(process.env.ENTRY_END_OFFSET);
const argv = process.argv.slice(2);

class RequestedExit extends Error {
  constructor(code) {
    super(`process.exit ${code}`);
    this.name = 'RequestedExit';
    this.code = code;
  }
}

function ensureEntryFile() {
  const extractedFile = path.join(workdir, `cli.${entryJsOffset}.${entryEndOffset}.bare-path.js`);
  if (fs.existsSync(extractedFile)) return extractedFile;

  const len = entryEndOffset - entryJsOffset;
  if (!(len > 0)) throw new Error('invalid replay offsets');

  const fd = fs.openSync(sourceBin, 'r');
  const buf = Buffer.alloc(len);
  fs.readSync(fd, buf, 0, len, entryJsOffset);
  fs.closeSync(fd);

  fs.writeFileSync(extractedFile, buf.toString('utf8').replace(/[\0\s]+$/g, ''));
  return extractedFile;
}

function stringWidth(value) {
  const text = String(value ?? '');
  if (typeof Intl !== 'undefined' && typeof Intl.Segmenter === 'function') {
    const segmenter = new Intl.Segmenter('en', { granularity: 'grapheme' });
    let width = 0;
    for (const _segment of segmenter.segment(text)) width += 1;
    return width;
  }
  return Array.from(text).length;
}

function createFakeRequire(realRequire) {
  const realChild = realRequire('child_process');

  function rewriteArgs(args) {
    if (
      Array.isArray(args) &&
      args[0] === 'xdg-open' &&
      Array.isArray(args[1]) &&
      typeof args[1][0] === 'string'
    ) {
      return ['termux-open-url', [args[1][0]], ...args.slice(2)];
    }
    return args;
  }

  const guardedChild = createGuardedChildProcess(
    {
      spawn: (...args) => realChild.spawn(...rewriteArgs(args)),
      execFile: (...args) => realChild.execFile(...args),
      exec: (...args) => realChild.exec(...args),
      spawnSync: (...args) => realChild.spawnSync(...rewriteArgs(args)),
      execFileSync: (...args) => realChild.execFileSync(...args),
      execSync: (...args) => realChild.execSync(...args),
    },
    value => process.stderr.write(value),
  );

  return function fakeRequire(id) {
    if (id === 'ws') {
      class WS {
        on() {}
        once() {}
        addEventListener() {}
        close() {}
        send() {}
        ping() {}
      }
      return { default: WS, WebSocket: WS };
    }

    if (id === 'child_process') {
      return guardedChild;
    }

    if (id === 'node:child_process') {
      return guardedChild;
    }

    if (id === 'vm' || id === 'node:vm') {
      const realVm = realRequire('vm');
      if (!realVm.__termuxBunPatched) {
        realVm.__termuxBunPatched = true;
        const origCC = realVm.createContext.bind(realVm);
        const origRIN = realVm.runInNewContext.bind(realVm);
        realVm.createContext = (ctx, ...args) => {
          if (ctx && typeof ctx === 'object' && !Object.prototype.hasOwnProperty.call(ctx, 'Bun')) {
            try { Object.defineProperty(ctx, 'Bun', { value: globalThis.Bun, configurable: true, writable: true }); } catch {}
          }
          return origCC(ctx, ...args);
        };
        realVm.runInNewContext = (code, ctx, ...args) => {
          if (ctx && typeof ctx === 'object' && !Object.prototype.hasOwnProperty.call(ctx, 'Bun')) {
            try { Object.defineProperty(ctx, 'Bun', { value: globalThis.Bun, configurable: true, writable: true }); } catch {}
          }
          return origRIN(code, ctx, ...args);
        };
      }
      return realVm;
    }

    if (id.startsWith('/$bunfs/root/')) {
      throw new Error('bunfs require blocked: ' + id);
    }

    return realRequire(id);
  };
}

function createBunShim(realChild) {
  const _rc = realChild || require('child_process');
  function _stripANSI(s) {
    return String(s ?? '').replace(/\x1B(?:[@-Z\\-_]|\[[0-?]*[ -\/]*[@-~]|\][^\x07\x1B]*(?:\x07|\x1B\\))/g, '');
  }
  return {
    version: '1.1.8',
    stringWidth,
    stripANSI: _stripANSI,
    wrapAnsi: (str, cols) => {
      const s = String(str ?? '');
      if (!cols || cols <= 0) return s;
      if (stringWidth(_stripANSI(s)) <= cols) return s;
      return s.slice(0, cols);
    },
    hash: (val) => { let h = 5381; for (const c of String(val ?? '')) h = ((h << 5) + h) ^ c.charCodeAt(0); return h >>> 0; },
    which: (cmd) => {
      try { return _rc.execFileSync('which', [String(cmd)], { encoding: 'utf8' }).trim() || null; } catch { return null; }
    },
    semver: (() => {
      const _cmp = (a, b) => { const pa = String(a).replace(/[^0-9.]/g,'').split('.').map(Number); const pb = String(b).replace(/[^0-9.]/g,'').split('.').map(Number); for (let i=0;i<3;i++){const d=(pa[i]||0)-(pb[i]||0);if(d)return d>0?1:-1;} return 0; };
      const _sat = (v,r) => { const m=String(r).trim().match(/^([><=!]{1,2})\s*([\d.]+)$/); if(m){const c=_cmp(v,m[2]);if(m[1]==='>')return c>0;if(m[1]==='>='||m[1]==='=')return c>=0;if(m[1]==='<')return c<0;if(m[1]==='<=')return c<=0;if(m[1]==='!=')return c!==0;} return _cmp(v,String(r).trim())===0; };
      return { order:_cmp, compare:_cmp, satisfies:_sat, gt:(a,b)=>_cmp(a,b)>0, gte:(a,b)=>_cmp(a,b)>=0, lt:(a,b)=>_cmp(a,b)<0, lte:(a,b)=>_cmp(a,b)<=0 };
    })(),
    YAML: {
      parse: (str) => {
        try {
          const result = {};
          for (const line of String(str ?? '').split('\n')) {
            const m = line.match(/^([\w-]+):\s*(.*)$/);
            if (!m) continue;
            const [, k, v] = m;
            if (v === 'true') result[k] = true;
            else if (v === 'false') result[k] = false;
            else if (v === 'null' || v === '~') result[k] = null;
            else if (/^-?[0-9]+(\.[0-9]+)?$/.test(v)) result[k] = Number(v);
            else if (v.startsWith('[')) { try { result[k] = JSON.parse(v.replace(/'/g,'"')); } catch { result[k] = v; } }
            else result[k] = v.replace(/^['"](.*)['"]$/, '$1');
          }
          return result;
        } catch { return {}; }
      },
      stringify: (obj) => typeof obj === 'string' ? obj : (obj == null ? '' : Object.entries(obj).map(([k,v]) => k+': '+JSON.stringify(v)).join('\n')),
    },
  };
}

async function main() {
  const extractedFile = ensureEntryFile();
  let code = fs.readFileSync(extractedFile, 'utf8');
  globalThis.__claudeYaml = globalThis.Bun && globalThis.Bun.YAML;
  const _yamlFixed = code.replace(
    /function\s+\w+\s*\(\w+\)\s*\{\s*return\s+Bun\.YAML\.parse\(\w+\)\s*\}/g,
    'function t5q(q){return (globalThis.__claudeYaml||globalThis.Bun.YAML).parse(q)}'
  );
  if (_yamlFixed === code) {
    process.stderr.write('[termux-shim] YAML.parse pattern not found (version: ' + (process.env.CURRENT_CLAUDE_VERSION||'?') + ')\n');
  }
  code = _yamlFixed;
  const fn = eval('(' + code);

  const originalArgv = process.argv.slice();
  const originalExit = process.exit;
  const originalBun = process.versions.bun;
  const hadGlobalBun = Object.prototype.hasOwnProperty.call(globalThis, 'Bun');
  const originalGlobalBun = globalThis.Bun;
  const asyncErrors = [];

  const fakeRequire = createFakeRequire(require);
  function onAsyncError(error) {
    asyncErrors.push(error);
  }

  try {
    process.once('uncaughtException', onAsyncError);
    process.once('unhandledRejection', onAsyncError);
    Object.defineProperty(process.versions, 'bun', { value: '1.1.8', configurable: true });
    const _shimBun = createBunShim(require('child_process'));
    if (typeof globalThis.Bun === 'undefined') {
      globalThis.Bun = _shimBun;
    } else {
      if (!globalThis.Bun.version) globalThis.Bun.version = _shimBun.version;
      if (!globalThis.Bun.stringWidth) globalThis.Bun.stringWidth = _shimBun.stringWidth;
      if (!globalThis.Bun.which) globalThis.Bun.which = _shimBun.which;
      if (!globalThis.Bun.semver) globalThis.Bun.semver = _shimBun.semver;
      if (!globalThis.Bun.wrapAnsi) globalThis.Bun.wrapAnsi = _shimBun.wrapAnsi;
      if (!globalThis.Bun.stripANSI) globalThis.Bun.stripANSI = _shimBun.stripANSI;
      if (!globalThis.Bun.hash) globalThis.Bun.hash = _shimBun.hash;
      if (!globalThis.Bun.YAML || typeof globalThis.Bun.YAML.parse !== 'function') globalThis.Bun.YAML = _shimBun.YAML;
    }
    process.argv = ['node', extractedFile, ...argv];
    process.exit = code => {
      throw new RequestedExit(code);
    };

    const moduleLike = { exports: {} };
    const maybePromise = fn(moduleLike.exports, fakeRequire, moduleLike, extractedFile, workdir);
    if (maybePromise && typeof maybePromise.then === 'function') await maybePromise;
    await new Promise(resolve => setTimeout(resolve, 200));
    if (asyncErrors.length > 0) throw asyncErrors[0];
  } catch (error) {
    if (error instanceof RequestedExit) {
      process.exitCode = error.code;
      return;
    }
    throw error;
  } finally {
    process.removeListener('uncaughtException', onAsyncError);
    process.removeListener('unhandledRejection', onAsyncError);
    process.argv = originalArgv;
    process.exit = originalExit;
    try {
      if (originalBun === undefined) {
        delete process.versions.bun;
      } else {
        Object.defineProperty(process.versions, 'bun', { value: originalBun, configurable: true });
      }
    } catch {}
    if (hadGlobalBun) globalThis.Bun = originalGlobalBun;
    else delete globalThis.Bun;
  }
}

main().catch(error => {
  if (error && error.code === 'CLAUDE_TERMUX_OFFICIAL_UPDATE_BLOCKED') {
    console.error(BLOCK_MESSAGE);
    process.exit(error.status || 1);
  }
  console.error(error && error.stack ? error.stack : String(error));
  process.exit(1);
});
NODE
  export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC="${CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:-1}"
  export ENABLE_CLAUDEAI_MCP_SERVERS="${ENABLE_CLAUDEAI_MCP_SERVERS:-0}"
  export CLAUDE_CODE_SIMPLE="${CLAUDE_CODE_SIMPLE:-1}"
  node "$_helper" "$@" </dev/null
  _status=$?
  rm -f "$_helper"
  trap - EXIT HUP INT TERM
  exit "$_status"
else
  _bootstrap=$(mktemp "${TMPDIR:-/tmp}/claude-bootstrap.XXXXXX.js")
  trap 'rm -f "$_bootstrap"' EXIT HUP INT TERM
  cat <<'NODE' > "$_bootstrap"
const fs = require('fs');
const path = require('path');
const {
  BLOCK_MESSAGE,
  createGuardedChildProcess,
} = require(path.join(process.env.CLAUDE_TERMUX_PACKAGE_DIR, 'lib', 'native-update-guard.js'));

const sourceBin = process.env.SOURCE_BIN;
const workdir = process.env.WORKDIR;
const entryJsOffset = Number(process.env.ENTRY_JS_OFFSET);
const entryEndOffset = Number(process.env.ENTRY_END_OFFSET);
const argv = process.argv.slice(2);

class RequestedExit extends Error {
  constructor(code) {
    super(`process.exit ${code}`);
    this.name = 'RequestedExit';
    this.code = code;
  }
}

function ensureEntryFile() {
  const extractedFile = path.join(workdir, `cli.${entryJsOffset}.${entryEndOffset}.bare-path.js`);
  if (fs.existsSync(extractedFile)) return extractedFile;

  const len = entryEndOffset - entryJsOffset;
  if (!(len > 0)) throw new Error('invalid replay offsets');

  const fd = fs.openSync(sourceBin, 'r');
  const buf = Buffer.alloc(len);
  fs.readSync(fd, buf, 0, len, entryJsOffset);
  fs.closeSync(fd);

  fs.writeFileSync(extractedFile, buf.toString('utf8').replace(/[\0\s]+$/g, ''));
  return extractedFile;
}

function stringWidth(value) {
  const text = String(value ?? '');
  if (typeof Intl !== 'undefined' && typeof Intl.Segmenter === 'function') {
    const segmenter = new Intl.Segmenter('en', { granularity: 'grapheme' });
    let width = 0;
    for (const _segment of segmenter.segment(text)) width += 1;
    return width;
  }
  return Array.from(text).length;
}

function createFakeRequire(realRequire) {
  const realChild = realRequire('child_process');

  function rewriteArgs(args) {
    if (
      Array.isArray(args) &&
      args[0] === 'xdg-open' &&
      Array.isArray(args[1]) &&
      typeof args[1][0] === 'string'
    ) {
      return ['termux-open-url', [args[1][0]], ...args.slice(2)];
    }
    return args;
  }

  const guardedChild = createGuardedChildProcess(
    {
      spawn: (...args) => realChild.spawn(...rewriteArgs(args)),
      execFile: (...args) => realChild.execFile(...args),
      exec: (...args) => realChild.exec(...args),
      spawnSync: (...args) => realChild.spawnSync(...rewriteArgs(args)),
      execFileSync: (...args) => realChild.execFileSync(...args),
      execSync: (...args) => realChild.execSync(...args),
    },
    value => process.stderr.write(value),
  );

  return function fakeRequire(id) {
    if (id === 'ws') {
      class WS {
        on() {}
        once() {}
        addEventListener() {}
        close() {}
        send() {}
        ping() {}
      }
      return { default: WS, WebSocket: WS };
    }

    if (id === 'child_process') {
      return guardedChild;
    }

    if (id === 'node:child_process') {
      return guardedChild;
    }

    if (id === 'vm' || id === 'node:vm') {
      const realVm = realRequire('vm');
      if (!realVm.__termuxBunPatched) {
        realVm.__termuxBunPatched = true;
        const origCC = realVm.createContext.bind(realVm);
        const origRIN = realVm.runInNewContext.bind(realVm);
        realVm.createContext = (ctx, ...args) => {
          if (ctx && typeof ctx === 'object' && !Object.prototype.hasOwnProperty.call(ctx, 'Bun')) {
            try { Object.defineProperty(ctx, 'Bun', { value: globalThis.Bun, configurable: true, writable: true }); } catch {}
          }
          return origCC(ctx, ...args);
        };
        realVm.runInNewContext = (code, ctx, ...args) => {
          if (ctx && typeof ctx === 'object' && !Object.prototype.hasOwnProperty.call(ctx, 'Bun')) {
            try { Object.defineProperty(ctx, 'Bun', { value: globalThis.Bun, configurable: true, writable: true }); } catch {}
          }
          return origRIN(code, ctx, ...args);
        };
      }
      return realVm;
    }

    if (id.startsWith('/$bunfs/root/')) {
      throw new Error('bunfs require blocked: ' + id);
    }

    return realRequire(id);
  };
}

function createBunShim(realChild) {
  const _rc = realChild || require('child_process');
  function _stripANSI(s) {
    return String(s ?? '').replace(/\x1B(?:[@-Z\\-_]|\[[0-?]*[ -\/]*[@-~]|\][^\x07\x1B]*(?:\x07|\x1B\\))/g, '');
  }
  return {
    version: '1.1.8',
    stringWidth,
    stripANSI: _stripANSI,
    wrapAnsi: (str, cols) => {
      const s = String(str ?? '');
      if (!cols || cols <= 0) return s;
      if (stringWidth(_stripANSI(s)) <= cols) return s;
      return s.slice(0, cols);
    },
    hash: (val) => { let h = 5381; for (const c of String(val ?? '')) h = ((h << 5) + h) ^ c.charCodeAt(0); return h >>> 0; },
    which: (cmd) => {
      try { return _rc.execFileSync('which', [String(cmd)], { encoding: 'utf8' }).trim() || null; } catch { return null; }
    },
    semver: (() => {
      const _cmp = (a, b) => { const pa = String(a).replace(/[^0-9.]/g,'').split('.').map(Number); const pb = String(b).replace(/[^0-9.]/g,'').split('.').map(Number); for (let i=0;i<3;i++){const d=(pa[i]||0)-(pb[i]||0);if(d)return d>0?1:-1;} return 0; };
      const _sat = (v,r) => { const m=String(r).trim().match(/^([><=!]{1,2})\s*([\d.]+)$/); if(m){const c=_cmp(v,m[2]);if(m[1]==='>')return c>0;if(m[1]==='>='||m[1]==='=')return c>=0;if(m[1]==='<')return c<0;if(m[1]==='<=')return c<=0;if(m[1]==='!=')return c!==0;} return _cmp(v,String(r).trim())===0; };
      return { order:_cmp, compare:_cmp, satisfies:_sat, gt:(a,b)=>_cmp(a,b)>0, gte:(a,b)=>_cmp(a,b)>=0, lt:(a,b)=>_cmp(a,b)<0, lte:(a,b)=>_cmp(a,b)<=0 };
    })(),
    YAML: {
      parse: (str) => {
        try {
          const result = {};
          for (const line of String(str ?? '').split('\n')) {
            const m = line.match(/^([\w-]+):\s*(.*)$/);
            if (!m) continue;
            const [, k, v] = m;
            if (v === 'true') result[k] = true;
            else if (v === 'false') result[k] = false;
            else if (v === 'null' || v === '~') result[k] = null;
            else if (/^-?[0-9]+(\.[0-9]+)?$/.test(v)) result[k] = Number(v);
            else if (v.startsWith('[')) { try { result[k] = JSON.parse(v.replace(/'/g,'"')); } catch { result[k] = v; } }
            else result[k] = v.replace(/^['"](.*)['"]$/, '$1');
          }
          return result;
        } catch { return {}; }
      },
      stringify: (obj) => typeof obj === 'string' ? obj : (obj == null ? '' : Object.entries(obj).map(([k,v]) => k+': '+JSON.stringify(v)).join('\n')),
    },
  };
}

async function main() {
  const extractedFile = ensureEntryFile();
  let code = fs.readFileSync(extractedFile, 'utf8');
  globalThis.__claudeYaml = globalThis.Bun && globalThis.Bun.YAML;
  const _yamlFixed = code.replace(
    /function\s+\w+\s*\(\w+\)\s*\{\s*return\s+Bun\.YAML\.parse\(\w+\)\s*\}/g,
    'function t5q(q){return (globalThis.__claudeYaml||globalThis.Bun.YAML).parse(q)}'
  );
  if (_yamlFixed === code) {
    process.stderr.write('[termux-shim] YAML.parse pattern not found (version: ' + (process.env.CURRENT_CLAUDE_VERSION||'?') + ')\n');
  }
  code = _yamlFixed;
  const fn = eval('(' + code);

  const originalArgv = process.argv.slice();
  const originalExit = process.exit;
  const originalBun = process.versions.bun;
  const hadGlobalBun = Object.prototype.hasOwnProperty.call(globalThis, 'Bun');
  const originalGlobalBun = globalThis.Bun;
  const asyncErrors = [];

  const fakeRequire = createFakeRequire(require);
  function onAsyncError(error) {
    asyncErrors.push(error);
  }

  try {
    process.once('uncaughtException', onAsyncError);
    process.once('unhandledRejection', onAsyncError);
    Object.defineProperty(process.versions, 'bun', { value: '1.1.8', configurable: true });
    const _shimBun = createBunShim(require('child_process'));
    if (typeof globalThis.Bun === 'undefined') {
      globalThis.Bun = _shimBun;
    } else {
      if (!globalThis.Bun.version) globalThis.Bun.version = _shimBun.version;
      if (!globalThis.Bun.stringWidth) globalThis.Bun.stringWidth = _shimBun.stringWidth;
      if (!globalThis.Bun.which) globalThis.Bun.which = _shimBun.which;
      if (!globalThis.Bun.semver) globalThis.Bun.semver = _shimBun.semver;
      if (!globalThis.Bun.wrapAnsi) globalThis.Bun.wrapAnsi = _shimBun.wrapAnsi;
      if (!globalThis.Bun.stripANSI) globalThis.Bun.stripANSI = _shimBun.stripANSI;
      if (!globalThis.Bun.hash) globalThis.Bun.hash = _shimBun.hash;
      if (!globalThis.Bun.YAML || typeof globalThis.Bun.YAML.parse !== 'function') globalThis.Bun.YAML = _shimBun.YAML;
    }
    process.argv = ['node', extractedFile, ...argv];
    process.exit = code => {
      throw new RequestedExit(code);
    };

    const moduleLike = { exports: {} };
    const maybePromise = fn(moduleLike.exports, fakeRequire, moduleLike, extractedFile, workdir);
    if (maybePromise && typeof maybePromise.then === 'function') await maybePromise;
    const _waitMs = process.stdin.isTTY ? 1200 : 200;
    await new Promise(resolve => setTimeout(resolve, _waitMs));
    if (asyncErrors.length > 0) throw asyncErrors[0];
  } catch (error) {
    if (error instanceof RequestedExit) {
      process.exitCode = error.code;
      return;
    }
    throw error;
  } finally {
    process.removeListener('uncaughtException', onAsyncError);
    process.removeListener('unhandledRejection', onAsyncError);
    process.argv = originalArgv;
    process.exit = originalExit;
    try {
      if (originalBun === undefined) {
        delete process.versions.bun;
      } else {
        Object.defineProperty(process.versions, 'bun', { value: originalBun, configurable: true });
      }
    } catch {}
    if (hadGlobalBun) globalThis.Bun = originalGlobalBun;
  }
}

main().catch(error => {
  if (error && error.code === 'CLAUDE_TERMUX_OFFICIAL_UPDATE_BLOCKED') {
    console.error(BLOCK_MESSAGE);
    process.exit(error.status || 1);
  }
  console.error(error && error.stack ? error.stack : String(error));
  process.exit(1);
});
NODE
  export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC="${CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:-1}"
  export ENABLE_CLAUDEAI_MCP_SERVERS="${ENABLE_CLAUDEAI_MCP_SERVERS:-0}"
  node "$_bootstrap" "$@"
  _status=$?
  rm -f "$_bootstrap"
  trap - EXIT HUP INT TERM
  exit "$_status"
fi
